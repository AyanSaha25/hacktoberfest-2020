For test the Image test:- 
open the deep_learning_object_detection.py file in terminal
python deep_learning_object_detection.py --image images/example_01.jpg --prototxt MobileNetSSD_deploy.prototxt.txt --model MobileNetSSD_deploy.caffemodel


For the real time:-
open the real_time_object_detection.py file in terminal
use itt python real_time_object_detection.py --prototxt MobileNetSSD_deploy.prototxt.txt --model MobileNetSSD_deploy.caffemodel